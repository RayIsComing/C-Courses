/*
 * File: C:\cvs\GDi_Documentation\EMS_Core\SPRK\Model\SS\Autocode\slprj\ert\_sharedutils\div_s32.h
 *
 *                   Delphi Powertrain Systems
 *
 *                   This document is the property of
 *                   Delphi Powertrain Systems
 *                   It must not be copied (in whole or in part)
 *                   or disclosed without prior written consent
 *                   of the company. Any copies by any method
 *                   must also include a copy of this legend.
 *
 * Real-Time Workshop code generated for Simulink model sprkmss.
 *
 * Model version                        : 1.457
 * Real-Time Workshop file version      : 7.0  (R2007b)  02-Aug-2007
 * Real-Time Workshop file generated on : Wed Sep 08 13:38:13 2010
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Wed Sep 08 13:38:14 2010
 */

#ifndef SHARE_div_s32
#define SHARE_div_s32

extern int32_T div_s32(int32_T sf_numerator, int32_T sf_denominator);

#endif

