/*
 * File: C:\cvs\BMW_DPH_Layer\BMW_Projects\B38_PST1\Output\Autocode\slprj\ert\_sharedutils\div_s32_sat_floor.h
 *
 *                   Delphi Powertrain Systems
 *
 *                   This document is the property of
 *                   Delphi Powertrain Systems
 *                   It must not be copied (in whole or in part)
 *                   or disclosed without prior written consent
 *                   of the company. Any copies by any method
 *                   must also include a copy of this legend.
 *
 * Real-Time Workshop code generated for Simulink model bmwl_ConvD2B.
 *
 * Model version                        : 1.1
 * Real-Time Workshop file version      : 7.0  (R2007b)  02-Aug-2007
 * Real-Time Workshop file generated on : Tue Feb 09 08:12:19 2010
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Tue Feb 09 08:12:20 2010
 */

#ifndef SHARE_div_s32_sat_floor
#define SHARE_div_s32_sat_floor

extern int32_T div_s32_sat_floor(int32_T numerator, int32_T denominator);

#endif

