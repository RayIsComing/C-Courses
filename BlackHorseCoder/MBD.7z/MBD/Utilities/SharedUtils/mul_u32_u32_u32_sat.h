/*
 * File: C:\cvs\GDi_Documentation_JUS\EMS_Core\VVTS\Model\BLDC_CTRL_SPD_TMP\Autocode\slprj\ert\_sharedutils\mul_u32_u32_u32_sat.h
 *
 *                   Delphi Powertrain Systems
 *
 *                   This document is the property of
 *                   Delphi Powertrain Systems
 *                   It must not be copied (in whole or in part)
 *                   or disclosed without prior written consent
 *                   of the company. Any copies by any method
 *                   must also include a copy of this legend.
 *
 * Real-Time Workshop code generated for Simulink model vvts_bldcctrl.
 *
 * Model version                        : 1.243
 * Real-Time Workshop file version      : 7.0  (R2007b)  02-Aug-2007
 * Real-Time Workshop file generated on : Thu Jun 17 14:32:14 2010
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Thu Jun 17 14:32:15 2010
 */

#ifndef SHARE_mul_u32_u32_u32_sat
#define SHARE_mul_u32_u32_u32_sat

extern uint32_T mul_u32_u32_u32_sat(uint32_T a, uint32_T b);

#endif

