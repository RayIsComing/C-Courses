/*
 * File: C:\EMS\Autocode\Diesel_Autocode_pojects\US_Gas\projFiles\simulink\models\tse_gpf_temp_est_files\slprj\ert\_sharedutils\mul_s32_s32_u32_sr15.h
 *
 *                   Delphi Diesel Systems
 *
 *                   This document is the property of
 *                   Delphi Diesel Systems
 *                   It must not be copied (in whole or in part)
 *                   or disclosed without prior written consent
 *                   of the company. Any copies by any method
 *                   must also include a copy of this legend.
 *
 * Real-Time Workshop code generated for Simulink model tse_gpf_temp_est.
 *
 * Real-Time Workshop file version      : 8.1 (R2011b) 08-Jul-2011
 * Real-Time Workshop file generated on : Mon Feb 26 10:15:59 2018
 * TLC version                          : 8.1 (Jul  9 2011)
 * C source code generated on           : Mon Feb 26 10:16:00 2018
 */

#ifndef SHARE_mul_s32_s32_u32_sr15
#define SHARE_mul_s32_s32_u32_sr15

extern S32 mul_s32_s32_u32_sr15(S32 a, U32 b);

#endif
