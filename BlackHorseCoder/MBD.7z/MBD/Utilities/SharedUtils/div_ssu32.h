/*
 * File: C:\EMS\Autocode\Diesel_Autocode_pojects\US_Gas\projFiles\simulink\models\p_t_gpf_dp_soot_mass_est_files\slprj\ert\_sharedutils\div_ssu32.h
 *
 *                   Delphi Diesel Systems
 *
 *                   This document is the property of
 *                   Delphi Diesel Systems
 *                   It must not be copied (in whole or in part)
 *                   or disclosed without prior written consent
 *                   of the company. Any copies by any method
 *                   must also include a copy of this legend.
 *
 * Real-Time Workshop code generated for Simulink model p_t_gpf_dp_soot_mass_est.
 *
 * Real-Time Workshop file version      : 8.1 (R2011b) 08-Jul-2011
 * Real-Time Workshop file generated on : Mon Feb 26 09:12:06 2018
 * TLC version                          : 8.1 (Jul  9 2011)
 * C source code generated on           : Mon Feb 26 09:12:06 2018
 */

#ifndef SHARE_div_ssu32
#define SHARE_div_ssu32

extern S32 div_ssu32(S32 numerator, U32 denominator);

#endif

