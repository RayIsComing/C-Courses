/*
 * File: d:\cvs\gsxxxwa\simulink\models\slprj\ert\_sharedutils\div_sus32_sat.h
 *
 *                   Delphi Diesel Systems
 *
 *                   This document is the property of
 *                   Delphi Diesel Systems
 *                   It must not be copied (in whole or in part)
 *                   or disclosed without prior written consent
 *                   of the company. Any copies by any method
 *                   must also include a copy of this legend.
 *
 * Real-Time Workshop code generated for Simulink model acm_vgt_bst_dmnd.
 *
 * Model version                        : 1.231
 * Real-Time Workshop file version      : 6.3  (R14SP3)  26-Jul-2005
 * Real-Time Workshop file generated on : Fri Nov 25 14:22:09 2005
 * TLC version                          : 6.3 (Aug  5 2005)
 * C source code generated on           : Fri Nov 25 14:22:09 2005
 */

#ifndef SHARE_div_sus32_sat
#define SHARE_div_sus32_sat

extern S32 div_sus32_sat(U32 numerator, S32 denominator);

#endif

