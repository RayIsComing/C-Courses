extern float ApplyFILT_1stOrderLag_ssp(float LfFILT_Old,
                               float LfFILT_New,
                               float LfFILT_k_Coeff );
 
  
extern float ApplyFILT_1stOrderLagIfEnbld_ssp(
                                float      LfFILT_Old,
                                float      LfFILT_New,
                                float  LfFILT_k_Coef );
								
extern signed short ApplyFILT_1stOrderLag_ssp_fixed(signed short LfFILT_Old_f,
                               signed short LfFILT_New_f,
                               unsigned short LfFILT_k_Coeff_f );
 
  
extern signed short ApplyFILT_1stOrderLagIfEnbld_ssp_fixed(
                                signed short      LfFILT_Old_f,
                                signed short      LfFILT_New_f,
                                unsigned short      LfFILT_k_Coef_f );								
