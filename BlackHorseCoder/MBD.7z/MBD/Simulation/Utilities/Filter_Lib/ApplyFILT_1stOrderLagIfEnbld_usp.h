extern float ApplyFILT_1stOrderLag_usp(float LfFILT_Old,
                               float LfFILT_New,
                               float LfFILT_k_Coeff );
 
  
extern float ApplyFILT_1stOrderLagIfEnbld_usp(
                                float      LfFILT_Old,
                                float      LfFILT_New,
                                float  LfFILT_k_Coef );
								
extern unsigned short ApplyFILT_1stOrderLag_usp_fixed(unsigned short LfFILT_Old_f,
                               unsigned short LfFILT_New_f,
                               unsigned short LfFILT_k_Coeff_f );
 
  
extern unsigned short ApplyFILT_1stOrderLagIfEnbld_usp_fixed(
                                unsigned short      LfFILT_Old_f,
                                unsigned short      LfFILT_New_f,
                                unsigned short      LfFILT_k_Coef_f );								
