int ApplyFILT_1stOrderLag_ssp(int,int,unsigned int);

unsigned int ApplyFILT_1stOrderLag_usp(unsigned int,unsigned int,unsigned int);
