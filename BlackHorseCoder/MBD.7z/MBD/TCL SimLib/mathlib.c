unsigned int usLookup_Rescale_xy_ss(int* RescaleMap,int InputVariable)
{
  return 1;
}
unsigned int usLookup_Rescale_xy_us(unsigned int* RescaleMap,unsigned int InputVariable)
{
  return 1;
}
unsigned int usLookup_xy_us(unsigned int* Map, unsigned int ScaledVariable )
{
  return 1;
}

extern unsigned int usLookup_xyz_us_us(unsigned int* Map, unsigned int ScaledVariable1, unsigned int ScaledVariable2 )
{
  return 1;
}
int ssLookup_xy_us(int* Map, unsigned int ScaledVariable )
{
  return 1;
}

extern int ssLookup_xyz_us_us(int* Map, unsigned int ScaledVariable1, unsigned int ScaledVariable2 )
{
  return 1;
}

unsigned int usLookup_Independent_xy_us(unsigned int* Map, unsigned int ScaledVariable )
{
  return 1;
}

int ssLookup_Independent_xy_us(int* Map, unsigned int ScaledVariable )
{
  return 1;
}

unsigned int usLookup_Independent_xy_ss(unsigned int* Map, unsigned int ScaledVariable )
{
  return 1;
}

int ssLookup_Independent_xy_ss(int* Map, unsigned int ScaledVariable )
{
  return 1;
}

