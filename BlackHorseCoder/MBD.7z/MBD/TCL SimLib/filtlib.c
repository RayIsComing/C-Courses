int ApplyFILT_1stOrderLag_ssp(int u1,int u2,unsigned int u3)
{
  return 0;
}

unsigned int ApplyFILT_1stOrderLag_usp(unsigned int u1,unsigned int u2,unsigned int u3)
{
  return 0;
}
